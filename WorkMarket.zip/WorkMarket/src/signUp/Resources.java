package signUp;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Resources {

	public WebDriver driver;
	String dataPropLocation = "/Users/rumi/Documents/workspace/WorkMarket/src/signUp/data.properties"; 
	
	public WebDriver initalizeDriver() throws IOException
	{
		
	Properties prop = new Properties();
	FileInputStream fis = new FileInputStream(dataPropLocation);
	
	prop.load(fis);
	
	String browserName = prop.getProperty("Browser");
	
	if(browserName.contains("chrome"))
	{
		System.setProperty("webdriver.chrome.driver", prop.getProperty("DriverPathChrome"));
		 driver =new ChromeDriver();
		
		
	}else if(browserName.contains("firefox"))
	{
		System.setProperty("webdriver.gecko.driver", prop.getProperty("DriverPathFirefox"));
		driver=new FirefoxDriver();
	}else if(browserName.contains("IE"))
	{
		driver=new InternetExplorerDriver();
	}
	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	return driver;
	
	}
	public void getScreenshot(String result) throws IOException
	{
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C://test//"+result+"screenshot.png"));
		
	}
	
	

}
