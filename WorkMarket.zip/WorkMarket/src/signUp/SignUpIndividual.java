package signUp;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SignUpIndividual extends Resources{
	String dataPropLocation = "/Users/rumi/Documents/workspace/WorkMarket/src/signUp/data.properties"; //location of data.properties file

	
	@BeforeTest
	public void lauchBrowser() throws IOException{
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(dataPropLocation);
		prop.load(fis);
		
		driver=initalizeDriver();
		driver.get(prop.getProperty("URL"));
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
	@AfterTest 
	public void closeBrowser() throws IOException, InterruptedException{
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(dataPropLocation);
		prop.load(fis);
		//Thread.sleep(700);
		//driver.close();
		//driver=null;
	}
	
	@Test(dataProvider="SignUpData")
	public void signUpValid(String firstName, String lastName, String Email, String Pass) throws InterruptedException{
		
	WebElementsSignUp s= new WebElementsSignUp(driver); //object of class WebElementsSignUp to use methods from that class
		
		s.getJoinIndivdButton().click();
		s.getFirstName().sendKeys(firstName);
		s.getLastName().sendKeys(lastName);
		Thread.sleep(500);
		s.getEmail().sendKeys(Email);
		s.getPassword().sendKeys(Pass);
		s.getCheckbox().click();
		s.getRegisterButton().click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		
	}
	
	
	@DataProvider
	public Object[][] SignUpData(){
		
		Object [][] data= new Object [1][4];
		
		data [0][0]= "Jo";//first name 
		data [0][1]= "Riley";//last name 
		data [0][2]= "abc123test@aol.com";//email
		data [0][3]= "PasswordField!";//password 
		
		/*data [1][0]= "Rusdfmi";//first name 
		data [1][1]= "begsdfum";//last name 
		data [1][2]= "kjhsdcdsdj@aol.com";//email
		data [1][3]= "vsasdfghjdv";//password 
		
		data [2][0]= "Rumdsdfsdi";//first name 
		data [2][1]= "fsfsfsd";//last name 
		data [2][2]= "sfff@aol.com";//email
		data [2][3]= "sfsdfsd2345";//password */
		
		return data;
	}


}
