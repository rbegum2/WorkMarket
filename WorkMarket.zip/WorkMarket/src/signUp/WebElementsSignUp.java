package signUp;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class WebElementsSignUp {

	public WebDriver driver;
	By JoinIndividualButton = By.xpath(".//*[@id='landing-page-bucket']/div/div[1]/div[2]/div[2]/div/button");
	By FirstName = By.cssSelector("input[name*='firstName']");
	By LastName= By.cssSelector("input[name*='lastName'");
	By Email = By.cssSelector("input[name*='email'");
	By Pass= By.cssSelector("input[name*='password'");
	By AgreeButton= By.cssSelector("input[type*='checkbox']");
	By RegisterButton= By.xpath(".//*[@id='landing-page-bucket']/div/div[2]/div[2]/footer/div/button");
	
	public WebElementsSignUp(WebDriver driver){
	
		this.driver=driver;
	}
	
	public WebElement getJoinIndivdButton(){
		return driver.findElement(JoinIndividualButton);	
	}
	public WebElement getFirstName(){
		return driver.findElement(FirstName);
	}
	public WebElement getLastName(){
		return driver.findElement(LastName);
	}
	public WebElement getEmail(){
		return driver.findElement(Email);
	}
	public WebElement getPassword(){
		return driver.findElement(Pass);
	}
	public WebElement getCheckbox(){
		return driver.findElement(AgreeButton);
	}
	public WebElement getRegisterButton(){
		return driver.findElement(RegisterButton);
	}
}
