package findTalent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SearchTextElements {
	
public WebDriver driver;
	
	By FindTalentLink = By.xpath(".//*[@id='home__Find Talent-button']/div/div");
	By SearchEdit = By.xpath(".//*[@id='input-text']");
	 
	

	
	public  SearchTextElements(WebDriver driver){
		
		this.driver=driver;
		
	}
	public WebElement getTalentLink(){
		return driver.findElement(FindTalentLink);
	}
	public WebElement getSearchEdit(){
		return driver.findElement(SearchEdit);
		
	}
	

}



