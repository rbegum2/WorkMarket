package findTalent;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SearchText extends Resources1{
	String dataPropLocation = "/Users/rumi/Documents/workspace/WorkMarket/src/findTalent/data2.properties"; 

	@BeforeTest
	public void lauchBrowser() throws IOException{

		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(dataPropLocation);
		prop.load(fis);
		
		driver=initalizeDriver();
		driver.get(prop.getProperty("URL"));
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	}
	@AfterTest 
	public void closeBrowser() throws IOException, InterruptedException{
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(dataPropLocation);
		prop.load(fis);
		//Thread.sleep(700);
		//driver.close();
		//driver=null;
	}
	@Test
	public void login() throws IOException{
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(dataPropLocation);
		prop.load(fis);
		
		Login Login = new Login(driver);
		Login.getEmail().sendKeys(prop.getProperty("Username"));
		Login.getPass().sendKeys(prop.getProperty("Password"));
		Login.getLoginButton().click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


	}
	
	@Test(dependsOnMethods = "login")
	public void Search(){
		String SearchValue = "test";
		SearchTextElements search= new SearchTextElements(driver);
		
		search.getTalentLink().click();
		search.getSearchEdit().sendKeys(SearchValue);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		search.getSearchEdit().sendKeys(Keys.RETURN);
		

	    List<WebElement>results= driver.findElements(By.id("search_results"));
	    
	    for(int i=1;i<results.size();i++){
	   Assert.assertTrue(results.get(i).getText().contains(SearchValue));
	    }
	}
	
	
}
