package findTalent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Login {
	
	public WebDriver driver;
	
	//By Email = By.cssSelector("input[@name*='userEmail']");
	By Email = By.name("userEmail");
	By Password = By.name("password");
	By LoginButton = By.xpath(".//*[@id='login_page_button']");
	

	
	public  Login(WebDriver driver){
		
		this.driver=driver;
		
	}
	public WebElement getEmail(){
		return driver.findElement(Email);
	}
	public WebElement getPass(){
		return driver.findElement(Password);
		
	}
	public WebElement getLoginButton(){
		return driver.findElement(LoginButton);
	}

}
